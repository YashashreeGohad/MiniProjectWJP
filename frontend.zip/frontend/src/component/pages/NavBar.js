import React from "react";
import styles from "../css/navbar.css";
import {
  Container,
  Nav,
  Navbar,
  NavDropdown,
  Form,
  Button,
} from "react-bootstrap";
const NavBar = () => {
  return (
    <>
      <nav>
        Show time
        <div>
          {/* <Link to={"/admin"}> */}
          <button>Admin Login</button>
          {/* </Link> */}
          {/* <Link to={"/signin"}> */}
          <button>Sign In</button>
          {/* </Link> */}
        </div>
      </nav>
    </>
  );
};

export default NavBar;
