import React from "react";
import "../css/aboutus.css";

import Footer from "./Footer";
import Signup from "./Signup";
import loginstatus from "../pages/Signinform";

import { Link, useNavigate } from "react-router-dom";
function AboutUs() {
  let navigate = useNavigate();

  let onSignup = () => {
    let userlogin = localStorage.getItem(loginstatus);
    if (userlogin) {
      navigate("/main");
    } else {
      navigate("/signup");
    }
  };
  return (
    <>
      <div>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>About us | Show Time</title>
        <link rel="stylesheet" href="aboutus.css" />
        <div className="header">
          <nav>
            Show Time ... all rights reserved
            <div>
              <Link to={"/admin"}>
                <button>Admin Login</button>
              </Link>

              <button onClick={onSignup}>Sign In</button>
            </div>
          </nav>
          <div className="header-content">
            <h1 style={{ justifyContent: "center" }}>About Us</h1>
            <h3>
            Welcome to our movie rating system website, where we are passionate about helping you 
            make informed decisions about the movies you watch. Our platform is dedicated to providing 
            comprehensive and reliable information on a wide range of movies, enabling you to discover 
            new films, explore various genres, and find the perfect movie for any occasion.

            </h3>
            <p>
            Our team is dedicated to delivering a seamless and user-friendly
              movie rating platform. We value your satisfaction and work hard to
              provide a smooth and immersive experience on all
              devices. Whether you're viewing our website on computer, smartphone, or
              smart TV, you can enjoy your favorite videos anytime, anywhere.
            </p>
            <h2 style={{ marginTop: "20px" }}>More About us Below</h2>
          </div>
        </div>
        <div className="features">
          <div className="row">
            <div className="text-col">
              <h2>1.Suhas Madane</h2>
              <p>Prn No - 2303 4052 0105</p>
            </div>
            <div className="img-col">{/* <img src={} /> */}</div>
          </div>
          <div className="row">
            <div className="img-col">{/* <img src={}/> */}</div>
            <div className="text-col">
              <h2>2.Yashashree Gohad</h2>
              <p>Prn No - 2303 4032 0137</p>
            </div>
          </div>
          <div className="row">
            <div className="text-col">
              <h2>3.Saurabh Wagh</h2>
              <p>Prn No - 2303 4032 0098</p>
            </div>
            <div className="img-col">{/* <img src={} /> */}</div>
          </div>
        </div>
        <div className="faq">
          <h2>Frequently Asked Questions About Our App</h2>
          <ul className="accordion">
            <li>
              <input type="radio" name="accordion" id="first" />
              <label htmlFor="first">How does your movie rating system work?</label>
              <div className="content">
                <p>
                Our movie rating system is a combination of expert opinions and community ratings. We have a team of dedicated
                 reviewers and industry professionals who provide their insights and ratings for movies. 
                </p>
              </div>
            </li>
            <li>
              <input type="radio" name="accordion" id="second" />
              <label htmlFor="second">Can I trust the ratings and reviews on your website?</label>
              <div className="content">
                <p>
                Yes, we take pride in providing reliable and trustworthy ratings and reviews. Our team of 
                experts ensures that the reviews are based on their honest opinions and expertise. 

                </p>
              </div>
            </li>
            <li>
              <input type="radio" name="accordion" id="third" />
              <label htmlFor="third">Can I contribute my own ratings and reviews?</label>
              <div className="content">
                <p>
                Absolutely! We encourage users to contribute their ratings and reviews to our platform. Your voice and opinions matter to us and the community.
                 You can sign up for an account and start sharing your thoughts on movies you've watched. 

                </p>
              </div>
            </li>
            <li>
              <input type="radio" name="accordion" id="fourth" />
              <label htmlFor="fourth">How are the personalized recommendations generated?</label>
              <div className="content">
                <p>
                Our personalized recommendation system takes into account your movie preferences and viewing history. By analyzing the movies you've rated positively and the
                 genres you enjoy, our algorithm suggests similar movies that align with your tastes
 
                </p>
              </div>
            </li>
            <li>
              <input type="radio" name="accordion" id="fifth" />
              <label htmlFor="fifth">Is your website accessible on mobile devices?</label>
              <div className="content">
                <p>
                Yes, our website is designed to be responsive and accessible on various devices, including mobile phones and tablets. You can enjoy browsing and accessing our movie ratings and reviews
                 on the go, making it convenient for you to make informed movie choices wherever you are.

                </p>
              </div>
            </li>
            <li>
              <input type="radio" name="accordion" id="sixth" />
              <label htmlFor="sixth">How often is your movie database updated?</label>
              <div className="content">
                <p>
                We strive to keep our movie database as up-to-date as possible. Our team continuously adds new releases, and
                 we aim to provide comprehensive coverage across various genres, languages, and eras.
                </p>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <Footer />
    </>
  );
}
export default AboutUs;


