import React from "react";

const DeleteMovie = () => {
  return <div>DeleteMovie</div>;
};

export default DeleteMovie;
